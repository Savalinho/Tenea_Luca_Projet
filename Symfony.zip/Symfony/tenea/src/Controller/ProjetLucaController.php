<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class ProjetLucaController extends AbstractController
{
    /**
     * @Route("/projet/luca", name="projet")
     */
    public function index(): Response
    {
        return $this->render('projet_luca/index.html.twig', [
            'controller_name' => 'ProjetLucaController',
        ]);
    }
    /**
     * @Route("/luca", name="projet_luca")
     */
    public function home()
    {
        return $this->render("projet_luca/base.html.twig");
    }
    
}
